package com.amani.amaniapirest.services.paciente;

import com.amani.amaniapirest.dto.dtoPaciente.response.UsuarioResponseDTO;
import com.amani.amaniapirest.models.Usuario;
import com.amani.amaniapirest.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

/**
 * Servicio de solo lectura que expone los datos de perfil del usuario autenticado como paciente.
 *
 * @see Usuario
 * @see com.amani.amaniapirest.dto.dtoPaciente.response.UsuarioResponseDTO
 */
@Service
public class UsuarioPacienteService {

    private final UsuarioRepository usuarioRepository;

    /**
     * Ejecuta la operación correspondiente a UsuarioPacienteService.
     *
     * @return Resultado de la operación o entidad procesada.
     */
    public UsuarioPacienteService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public UsuarioResponseDTO findById(Long idUsuario) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        return toResponse(usuario);
    }

    private UsuarioResponseDTO toResponse(Usuario usuario) {
        return new UsuarioResponseDTO(
                usuario.getNombre(),
                usuario.getApellido(),
                usuario.getEmail(),
                usuario.getRol(),
                usuario.getActivo(),
                usuario.getFechaRegistro()
        );
    }
}