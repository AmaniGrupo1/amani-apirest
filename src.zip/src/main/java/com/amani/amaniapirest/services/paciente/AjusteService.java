package com.amani.amaniapirest.services.paciente;

import com.amani.amaniapirest.dto.ajustes.IdiomaRequestDTO;
import com.amani.amaniapirest.dto.colorNegroBlanco.UpdateTemaDTO;
import com.amani.amaniapirest.dto.dtoPaciente.request.AjusteRequestDTO;
import com.amani.amaniapirest.dto.dtoPaciente.response.AjusteResponseDTO;
import com.amani.amaniapirest.models.Ajuste;
import com.amani.amaniapirest.models.Usuario;
import com.amani.amaniapirest.repository.AjusteRepository;
import com.amani.amaniapirest.repository.UsuarioRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Gestiona las preferencias personales de configuración de cada usuario de la plataforma.
 *
 * <p>Cubre el ciclo de vida completo de los ajustes: idioma de la interfaz, activación
 * de notificaciones, tema visual (oscuro/claro) y zona horaria. Si el usuario aún no
 * tiene ajustes creados, los métodos de actualización parcial los generan con valores
 * por defecto antes de aplicar el cambio solicitado.</p>
 *
 * @author Ivan Lopez
 * @since 1.0
 */
@Service
public class AjusteService {

    private final AjusteRepository ajusteRepository;
    private final UsuarioRepository usuarioRepository;

    /**
     * Construye el servicio con sus dependencias de repositorio.
     *
     * @param ajusteRepository  repositorio JPA de {@link Ajuste}
     * @param usuarioRepository repositorio JPA de {@link Usuario}
     */
    public AjusteService(AjusteRepository ajusteRepository, UsuarioRepository usuarioRepository) {
        this.ajusteRepository = ajusteRepository;
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Obtiene la lista de todos los ajustes registrados.
     *
     * @return lista de {@link AjusteResponseDTO} con todos los ajustes
     */
    public List<AjusteResponseDTO> findAll() {
        return ajusteRepository.findAll().stream().map(this::toResponse).toList();
    }

    /**
     * Busca un ajuste por su identificador único.
     *
     * @param idAjuste identificador del ajuste
     * @return {@link AjusteResponseDTO} con los datos del ajuste encontrado
     * @throws RuntimeException si no existe un ajuste con el id proporcionado
     */
    public AjusteResponseDTO findById(Long idAjuste) {
        return toResponse(getAjusteOrThrow(idAjuste));
    }

    /**
     * Busca los ajustes de un usuario específico.
     *
     * @param idUsuario identificador del usuario
     * @return {@link AjusteResponseDTO} con los ajustes del usuario
     * @throws RuntimeException si el usuario no tiene ajustes configurados
     */
    public AjusteResponseDTO findByUsuario(Long idUsuario) {
        return ajusteRepository.findByUsuario_IdUsuario(idUsuario)
                .map(this::toResponse)
                .orElseThrow(() -> new RuntimeException("Ajustes no encontrados para el usuario: " + idUsuario));
    }

    /**
     * Crea un nuevo registro de ajustes para un usuario.
     *
     * @param request {@link AjusteRequestDTO} con las preferencias del usuario
     * @return {@link AjusteResponseDTO} con los ajustes creados
     * @throws RuntimeException si el usuario referenciado no existe
     */
    public AjusteResponseDTO create(AjusteRequestDTO request) {
        Usuario usuario = getUsuarioOrThrow(request.getIdUsuario());

        Ajuste ajuste = new Ajuste();
        ajuste.setUsuario(usuario);
        ajuste.setIdioma(request.getIdioma());
        ajuste.setNotificaciones(request.getNotificaciones() != null ? request.getNotificaciones() : true);
        ajuste.setTema(
                request.getTema() != null ? request.getTema() : false
        );
        ajuste.setTimezone(request.getTimezone());
        ajuste.setUpdatedAt(LocalDateTime.now());

        return toResponse(ajusteRepository.save(ajuste));
    }

    /**
     * Actualiza los ajustes de configuración existentes.
     *
     * @param idAjuste identificador del ajuste a actualizar
     * @param request  {@link AjusteRequestDTO} con las nuevas preferencias
     * @return {@link AjusteResponseDTO} con los ajustes actualizados
     * @throws RuntimeException si el ajuste o el usuario referenciado no existen
     */
    public AjusteResponseDTO update(Long idAjuste, AjusteRequestDTO request) {
        Ajuste ajuste = getAjusteOrThrow(idAjuste);
        Usuario usuario = getUsuarioOrThrow(request.getIdUsuario());

        ajuste.setUsuario(usuario);
        ajuste.setIdioma(request.getIdioma());
        if (request.getNotificaciones() != null) ajuste.setNotificaciones(request.getNotificaciones());
        if (request.getTema() != null) {
            ajuste.setTema(request.getTema());
        }
        ajuste.setTimezone(request.getTimezone());
        ajuste.setUpdatedAt(LocalDateTime.now());

        return toResponse(ajusteRepository.save(ajuste));
    }

    /**
     * Elimina el ajuste con el identificador indicado.
     *
     * @param idAjuste identificador del ajuste a eliminar
     * @throws RuntimeException si no existe un ajuste con el id proporcionado
     */
    public void delete(Long idAjuste) {
        ajusteRepository.delete(getAjusteOrThrow(idAjuste));
    }

    /**
     * Recupera un ajuste por id o lanza excepción si no existe.
     *
     * @param idAjuste identificador del ajuste
     * @return entidad {@link Ajuste} encontrada
     * @throws RuntimeException si no existe un ajuste con el id proporcionado
     */
    private Ajuste getAjusteOrThrow(Long idAjuste) {
        return ajusteRepository.findById(idAjuste)
                .orElseThrow(() -> new RuntimeException("Ajuste no encontrado con id: " + idAjuste));
    }

    /**
     * Recupera un usuario por id o lanza excepción si no existe.
     *
     * @param idUsuario identificador del usuario
     * @return entidad {@link Usuario} encontrada
     * @throws RuntimeException si no existe un usuario con el id proporcionado
     */
    private Usuario getUsuarioOrThrow(Long idUsuario) {
        return usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con id: " + idUsuario));
    }

    /**
     * Convierte una entidad {@link Ajuste} en su DTO de respuesta.
     *
     * @param ajuste entidad a convertir
     * @return {@link AjusteResponseDTO} con los datos mapeados
     */
    private AjusteResponseDTO toResponse(Ajuste ajuste) {
        return new AjusteResponseDTO(
                ajuste.getIdAjuste(),
                ajuste.getUsuario() != null ? ajuste.getUsuario().getIdUsuario() : null,
                ajuste.getIdioma(),
                ajuste.isNotificaciones(),
                ajuste.getTema(),
                ajuste.getTimezone(),
                ajuste.getUpdatedAt()
        );
    }


    /**
     * Actualiza el idioma preferido de un usuario, creando el registro de ajustes si aún no existe.
     *
     * <p>Si el usuario no tiene ajustes previos, se crea un nuevo registro vinculado
     * antes de establecer el idioma solicitado.</p>
     *
     * @param idUsuario identificador del usuario cuyo idioma se actualizará
     * @param request   DTO con el código de idioma a establecer (por ejemplo, {@code "es"}, {@code "en"})
     * @throws RuntimeException si el usuario no existe
     */
    @Transactional
    public void actualizarIdioma(Long idUsuario, IdiomaRequestDTO request) {
        Ajuste ajuste = ajusteRepository.findByUsuario_IdUsuario(idUsuario)
                .orElseGet(() -> {
                    Ajuste nuevo = new Ajuste();
                    nuevo.setUsuario(usuarioRepository.findById(idUsuario)
                            .orElseThrow(() -> new RuntimeException("Usuario no encontrado")));
                    return nuevo;
                });

        ajuste.setIdioma(request.getIdioma());
        ajusteRepository.save(ajuste);
    }


    /**
     * Cambia el tema visual del usuario entre modo oscuro ({@code true}) y modo claro ({@code false}).
     *
     * <p>Si el usuario no tiene ajustes previos, se crea un registro con valores por defecto
     * (idioma {@code "es"}, notificaciones activadas, tema claro, zona horaria {@code "Europe/Madrid"})
     * antes de aplicar el tema solicitado.</p>
     *
     * @param idUsuario identificador del usuario cuyo tema se actualizará
     * @param dto       DTO con el valor booleano del nuevo tema
     * @return {@link AjusteResponseDTO} con los datos del ajuste actualizado
     * @throws RuntimeException si el usuario no existe
     */
    @Transactional
    public AjusteResponseDTO actualizarTema(Long idUsuario,UpdateTemaDTO dto) {

        Ajuste ajuste = ajusteRepository
                .findByUsuario_IdUsuario(idUsuario)
                .orElseGet(() -> {

                    Usuario usuario = usuarioRepository.findById(idUsuario)
                            .orElseThrow(() ->
                                    new RuntimeException("Usuario no encontrado"));

                    Ajuste nuevo = new Ajuste();
                    nuevo.setUsuario(usuario);

                    nuevo.setIdioma("es");
                    nuevo.setNotificaciones(true);
                    nuevo.setTema(false);
                    nuevo.setTimezone("Europe/Madrid");
                    nuevo.setUpdatedAt(LocalDateTime.now());

                    return nuevo;
                });

        ajuste.setTema(dto.getTema());

        ajuste.setUpdatedAt(LocalDateTime.now());

        Ajuste guardado = ajusteRepository.save(ajuste);

        return toResponse(guardado);
    }
}

