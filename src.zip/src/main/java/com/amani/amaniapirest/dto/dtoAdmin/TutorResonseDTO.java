package com.amani.amaniapirest.dto.dtoAdmin;

import io.swagger.v3.oas.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO de respuesta para representar un tutor o responsable legal de un paciente.
 *
 * <p>Contiene los datos de contacto y de identificación del tutor,
 * utilizado principalmente para pacientes menores de edad o bajo tutela.</p>
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Objeto de transferencia de datos TutorResonseDTO")
public class TutorResonseDTO {
    private Long idTutor;
    private String nombre;
    private String telefono;
    private String email;
    private String dni;
    private String tipo;
}
