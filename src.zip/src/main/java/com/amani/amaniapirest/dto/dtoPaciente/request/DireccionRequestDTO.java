package com.amani.amaniapirest.dto.dtoPaciente.request;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO de entrada para registrar o actualizar una dirección de un paciente.
 *
 * <p>Los campos {@code idPaciente} y {@code calle} son obligatorios.
 * El resto de campos son opcionales.</p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Objeto de transferencia de datos DireccionRequestDTO")
public class DireccionRequestDTO {
        /** Identificador del paciente al que pertenece esta dirección. */
    private Long idPaciente;

    /** Nombre de la calle y número. */
    @NotBlank
    private String calle;

    /** Ciudad de residencia. */
    private String ciudad;

    /** Provincia o estado. */
    private String provincia;

    /** Código postal de la zona. */
    private String codigoPostal;

    /** País de residencia. */
    private String pais;

}
